package com.example.esfahansports

import androidx.compose.runtime.compositionLocalOf

data class HomeContent(
    val title: String,
    val subtitle: String,
    val topImage: String,
    val logo: String,
    val searchHint: String,
)

data class DetailsContent(
    val addressLabel: String,
    val googleButton: String,
    val baladButton: String,
    val locationButton: String,
)

data class AboutContent(
    val title: String,
    val text: String,
    val sources: String,
    val publisher: String,
    val copyright: String,
    val contactTitle: String,
    val email: String,
)

data class AppContent(
    val version: Int,
    val home: HomeContent,
    val details: DetailsContent,
    val about: AboutContent,
    val gyms: List<Gym>,
)

/** اطلاعات داخلی اپ؛ اگر اینترنت یا سایت در دسترس نباشد همین‌ها نمایش داده می‌شود. */
val BuiltInContent = AppContent(
    version = 0,
    home = HomeContent(
        title = "سالن‌های ورزشی فوتسال استان اصفهان",
        subtitle = "",
        topImage = "",
        logo = "",
        searchHint = "جستجوی سالن ...",
    ),
    details = DetailsContent(
        addressLabel = "آدرس متنی",
        googleButton = "مسیریابی\n(گوگل مپ)",
        baladButton = "مسیریابی\n(بلد)",
        locationButton = "نمایش\nدر نقشه",
    ),
    about = AboutContent(
        title = "درباره ما",
        text = "این برنامه آدرس و موقعیت سالن‌های ورزشی فوتسال استان اصفهان را روی نقشه‌های گوگل‌مپ و بلد نمایش می‌دهد.",
        sources = "منابع: سایت شهرداری اصفهان و اپلیکیشن بلد",
        publisher = "طراحی و اجرا: روح‌الله صفدری",
        copyright = "© ۱۴۰۵ روح‌الله صفدری. تمامی حقوق محفوظ است.",
        contactTitle = "تماس با ما",
        email = "Roohollahsafdary@gmail.com",
    ),
    gyms = builtInGyms,
)

val LocalContent = compositionLocalOf { BuiltInContent }
