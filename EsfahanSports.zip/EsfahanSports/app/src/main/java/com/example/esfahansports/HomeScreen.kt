package com.example.esfahansports

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** یکسان‌سازی حروف عربی/فارسی و حذف نیم‌فاصله و فاصله برای جستجوی دقیق‌تر */
fun normalize(s: String): String = s
    .replace('ي', 'ی')
    .replace('ك', 'ک')
    .replace("‌", "")
    .replace(" ", "")
    .lowercase()

fun Gym.matches(query: String): Boolean {
    val q = normalize(query)
    if (q.isEmpty()) return true
    return normalize(name).contains(q) ||
        normalize(city).contains(q) ||
        normalize(address).contains(q) ||
        aliases.any { normalize(it).contains(q) }
}

@Composable
fun Header(title: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(110.dp)
            .background(headerBrush),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            title,
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 24.dp),
        )
    }
}

@Composable
fun GymPhoto(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(placeholderBrush),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            Icons.Default.SportsSoccer,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.9f),
            modifier = Modifier.size(34.dp),
        )
    }
}

@Composable
fun GymCard(gym: Gym, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            GymPhoto(Modifier.size(78.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    gym.name,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Navy,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Place,
                        contentDescription = null,
                        tint = BlueMain,
                        modifier = Modifier.size(18.dp),
                    )
                    Text("  ${gym.city}", fontSize = 14.sp, color = Color(0xFF3A4A7A))
                }
            }
            Icon(
                Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = BlueMain,
            )
        }
    }
}

@Composable
fun GymList(items: List<Gym>, onOpen: (Gym) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            horizontal = 16.dp,
            vertical = 8.dp,
        ),
    ) {
        items(items, key = { it.id }) { gym -> GymCard(gym) { onOpen(gym) } }
    }
}

@Composable
fun HomeTab(onOpen: (Gym) -> Unit) {
    var query by remember { mutableStateOf("") }
    val results = remember(query) { gyms.filter { it.matches(query) } }

    Column(Modifier.fillMaxSize().background(ScreenBg)) {
        Header("سالن‌های ورزشی فوتسال\nاستان اصفهان")
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            placeholder = { Text("جستجوی سالن ...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = BlueMain) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "پاک کردن")
                    }
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White,
                focusedBorderColor = BlueMain,
                unfocusedBorderColor = Color.Transparent,
            ),
        )
        if (results.isEmpty()) {
            Text(
                "موردی پیدا نشد",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                textAlign = TextAlign.Center,
                color = Color(0xFF3A4A7A),
            )
        } else {
            GymList(results, onOpen, Modifier.fillMaxSize())
        }
    }
}

@Composable
fun FavoritesTab(favorites: FavoritesStore, onOpen: (Gym) -> Unit) {
    val items = gyms.filter { it.id in favorites.ids }
    Column(Modifier.fillMaxSize().background(ScreenBg)) {
        Header("علاقه‌مندی‌ها")
        if (items.isEmpty()) {
            Text(
                "هنوز سالنی را به علاقه‌مندی‌ها اضافه نکرده‌اید.\nدر صفحه‌ی هر سالن روی قلب بزنید.",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                textAlign = TextAlign.Center,
                color = Color(0xFF3A4A7A),
                lineHeight = 26.sp,
            )
        } else {
            GymList(items, onOpen, Modifier.fillMaxSize())
        }
    }
}

@Composable
fun AboutTab() {
    Column(Modifier.fillMaxSize().background(ScreenBg)) {
        Header("درباره ما")
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(100.dp))
                    .background(headerBrush),
            ) { AppLogo(size = 110) }
            Text(
                "آدرس سالن‌های ورزشی فوتسال استان اصفهان",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = Navy,
                textAlign = TextAlign.Center,
            )
            Text(
                "این برنامه آدرس و موقعیت سالن‌های ورزشی فوتسال استان اصفهان را روی نقشه‌های گوگل‌مپ و بلد نمایش می‌دهد.",
                textAlign = TextAlign.Center,
                color = Color(0xFF3A4A7A),
                lineHeight = 26.sp,
            )
            Text(
                "ناشر: روح‌الله صفدری",
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold,
                color = Navy,
                fontSize = 16.sp,
            )
            Text(
                "© ۱۴۰۵ روح‌الله صفدری. تمامی حقوق محفوظ است.",
                textAlign = TextAlign.Center,
                color = Color(0xFF7A86AD),
                fontSize = 13.sp,
            )
        }
    }
}

@Composable
fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color.White) {
        val colors = NavigationBarItemDefaults.colors(
            selectedIconColor = BlueMain,
            selectedTextColor = BlueMain,
            indicatorColor = Color(0xFFDDE5FF),
        )
        NavigationBarItem(
            selected = selected == 0,
            onClick = { onSelect(0) },
            icon = { Icon(Icons.Default.Home, contentDescription = null) },
            label = { Text("خانه") },
            colors = colors,
        )
        NavigationBarItem(
            selected = selected == 1,
            onClick = { onSelect(1) },
            icon = { Icon(Icons.Default.Star, contentDescription = null) },
            label = { Text("علاقه‌مندی‌ها") },
            colors = colors,
        )
        NavigationBarItem(
            selected = selected == 2,
            onClick = { onSelect(2) },
            icon = { Icon(Icons.Default.Info, contentDescription = null) },
            label = { Text("درباره ما") },
            colors = colors,
        )
    }
}
