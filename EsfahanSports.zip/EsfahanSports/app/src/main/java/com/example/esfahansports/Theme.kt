package com.example.esfahansports

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF0B1F6B)
val BlueMain = Color(0xFF1E48C8)
val BlueLight = Color(0xFF3F6BE8)
val Gold = Color(0xFFFFC21A)
val ScreenBg = Color(0xFFEEF2FF)

val headerBrush = Brush.verticalGradient(listOf(Navy, BlueMain))
val splashBrush = Brush.verticalGradient(listOf(Color(0xFF06123F), Navy, BlueMain))
val placeholderBrush = Brush.linearGradient(listOf(BlueMain, BlueLight))
