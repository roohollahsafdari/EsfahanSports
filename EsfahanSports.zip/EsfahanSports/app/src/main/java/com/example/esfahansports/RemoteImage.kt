package com.example.esfahansports

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import coil.compose.AsyncImage

/** عکس آنلاین؛ اگر آدرس خالی باشد یا دریافت نشود، عکس داخل اپ نمایش داده می‌شود. */
@Composable
fun RemoteImage(
    url: String?,
    @DrawableRes fallback: Int,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    alignment: Alignment = Alignment.Center,
) {
    val local = painterResource(fallback)
    if (url.isNullOrBlank()) {
        Image(local, null, modifier, contentScale = contentScale, alignment = alignment)
    } else {
        AsyncImage(
            model = url,
            contentDescription = null,
            modifier = modifier,
            placeholder = local,
            error = local,
            fallback = local,
            contentScale = contentScale,
            alignment = alignment,
        )
    }
}
