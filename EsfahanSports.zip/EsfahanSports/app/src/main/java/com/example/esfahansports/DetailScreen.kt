package com.example.esfahansports

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun openUrl(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "برنامه‌ای برای باز کردن لینک پیدا نشد", Toast.LENGTH_SHORT).show()
    }
}

/** «نمایش در نقشه»: اگر مختصات داریم با هر برنامه‌ی نقشه، وگرنه لینک گوگل‌مپ */
private fun showOnMap(context: Context, gym: Gym) {
    val lat = gym.latitude
    val lon = gym.longitude
    if (lat != null && lon != null) {
        val geo = Uri.parse("geo:$lat,$lon?q=$lat,$lon(${Uri.encode(gym.name)})")
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, geo))
            return
        } catch (e: ActivityNotFoundException) {
            // ادامه می‌دهیم و لینک گوگل‌مپ را باز می‌کنیم
        }
    }
    openUrl(context, gym.googleUrl)
}

@Composable
private fun ActionButton(
    label: String,
    icon: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            icon()
            Text(
                label,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = Navy,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
fun DetailScreen(gym: Gym, favorites: FavoritesStore, onBack: () -> Unit) {
    val context = LocalContext.current
    val det = LocalContent.current.details
    val isFav = gym.id in favorites.ids

    Column(Modifier.fillMaxSize().pageBackground()) {
        // نوار بالا
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(headerBrush)
                .padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { favorites.toggle(gym.id) }) {
                Icon(
                    if (isFav) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    contentDescription = "ذخیره",
                    tint = if (isFav) Gold else Color.White,
                )
            }
            Text(
                "جزئیات سالن",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "بازگشت", tint = Color.White)
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // نام و شهر روی عکس پس‌زمینه
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .clip(RoundedCornerShape(20.dp)),
            ) {
                RemoteImage(
                    url = gym.imageUrl,
                    fallback = R.drawable.gym_default,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    alignment = BiasAlignment(0f, -0.3f),
                )
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(listOf(Color(0x3306123F), Color(0xDD06123F)))
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        gym.name,
                        color = Color.White,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Place,
                            contentDescription = null,
                            tint = Gold,
                            modifier = Modifier.size(20.dp),
                        )
                        Text("  ${gym.city}", color = Color.White, fontSize = 15.sp)
                    }
                }
            }

            // دکمه‌ها
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionButton(
                    label = det.googleButton,
                    icon = { Icon(Icons.Default.Map, null, tint = BlueMain, modifier = Modifier.size(30.dp)) },
                    modifier = Modifier.weight(1f),
                ) { openUrl(context, gym.googleUrl) }
                ActionButton(
                    label = det.baladButton,
                    icon = { Icon(Icons.Default.Navigation, null, tint = BlueMain, modifier = Modifier.size(30.dp)) },
                    modifier = Modifier.weight(1f),
                ) { openUrl(context, gym.baladUrl) }
                ActionButton(
                    label = det.locationButton,
                    icon = { Icon(Icons.Default.Place, null, tint = BlueMain, modifier = Modifier.size(30.dp)) },
                    modifier = Modifier.weight(1f),
                ) { showOnMap(context, gym) }
            }

            // آدرس متنی
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Place,
                            contentDescription = null,
                            tint = BlueMain,
                            modifier = Modifier.size(20.dp),
                        )
                        Text(
                            "  ${det.addressLabel}",
                            fontWeight = FontWeight.Bold,
                            color = Navy,
                            fontSize = 16.sp,
                        )
                    }
                    Text(gym.address, color = Color(0xFF2A3560), fontSize = 15.sp, lineHeight = 26.sp)
                }
            }
        }
    }
}
