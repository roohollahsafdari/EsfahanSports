package com.example.esfahansports

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.paint
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

const val CONTACT_EMAIL = "Roohollahsafdary@gmail.com"

/** یکسان‌سازی حروف عربی/فارسی و حذف نیم‌فاصله و فاصله برای جستجوی دقیق‌تر */
fun normalize(s: String): String = s
    .replace('ي', 'ی')
    .replace('ك', 'ک')
    .replace("‌", "")
    .replace(" ", "")
    .lowercase()

fun Gym.matches(query: String): Boolean {
    val q = normalize(query)
    if (q.isEmpty()) return true
    return normalize(name).contains(q) ||
        normalize(city).contains(q) ||
        normalize(address).contains(q) ||
        aliases.any { normalize(it).contains(q) }
}

/** پس‌زمینه‌ی آبی تمام صفحه‌ها */
@Composable
fun Modifier.pageBackground(): Modifier =
    this.paint(painterResource(R.drawable.home_bg), contentScale = ContentScale.Crop)

/** تصویر بالای صفحه همراه با عنوان */
@Composable
fun HeroHeader(
    title: String,
    compact: Boolean = false,
    height: Dp? = null,
    progress: Float = 0f,
) {
    val boxModifier = when {
        height != null -> Modifier.fillMaxWidth().height(height)
        compact -> Modifier.fillMaxWidth().height(170.dp)
        else -> Modifier.fillMaxWidth().aspectRatio(1080f / 905f)
    }
    Box(boxModifier) {
        Image(
            painter = painterResource(R.drawable.home_header),
            contentDescription = null,
            modifier = Modifier.fillMaxSize().blur((progress * 10f).dp),
            contentScale = ContentScale.Crop,
            alignment = if (compact || height != null) BiasAlignment(0f, 0.1f) else Alignment.Center,
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xAA06123F))))
        )
        // با بالا رفتن لیست، تصویر تیره‌تر و تارتر می‌شود
        Box(
            Modifier
                .fillMaxSize()
                .background(Color(0xFF06123F).copy(alpha = 0.55f * progress))
        )
        Text(
            title,
            color = Color.White,
            fontSize = 19.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
        )
    }
}

@Composable
fun GymPhoto(modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.gym_default),
        contentDescription = null,
        modifier = modifier.clip(RoundedCornerShape(16.dp)),
        contentScale = ContentScale.Crop,
        alignment = BiasAlignment(0f, -0.2f),
    )
}

@Composable
fun GymCard(gym: Gym, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            GymPhoto(Modifier.size(78.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    gym.name,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Navy,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Place,
                        contentDescription = null,
                        tint = BlueMain,
                        modifier = Modifier.size(18.dp),
                    )
                    Text("  ${gym.city}", fontSize = 14.sp, color = Color(0xFF3A4A7A))
                }
            }
            Icon(
                Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = BlueMain,
            )
        }
    }
}

@Composable
fun GymList(items: List<Gym>, onOpen: (Gym) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
    ) {
        items(items, key = { it.id }) { gym -> GymCard(gym) { onOpen(gym) } }
    }
}

@Composable
fun HomeTab(onOpen: (Gym) -> Unit) {
    var query by remember { mutableStateOf("") }
    val results = remember(query) { gyms.filter { it.matches(query) } }

    // هدر با اسکرول لیست کوچک و تار می‌شود ولی در صفحه می‌ماند
    val density = LocalDensity.current
    val screenWidthDp = LocalConfiguration.current.screenWidthDp
    val maxPx = with(density) { (screenWidthDp * 905f / 1080f).dp.toPx() }
    val minPx = with(density) { 96.dp.toPx() }
    var headerPx by remember { mutableFloatStateOf(maxPx) }
    val currentPx = headerPx.coerceIn(minPx, maxPx)
    val progress = ((maxPx - currentPx) / (maxPx - minPx)).coerceIn(0f, 1f)

    val connection = remember(minPx, maxPx) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                val delta = available.y
                if (delta < 0f && headerPx > minPx) {
                    val newValue = (headerPx + delta).coerceAtLeast(minPx)
                    val consumed = newValue - headerPx
                    headerPx = newValue
                    return Offset(0f, consumed)
                }
                return Offset.Zero
            }

            override fun onPostScroll(
                consumed: Offset,
                available: Offset,
                source: NestedScrollSource,
            ): Offset {
                val delta = available.y
                if (delta > 0f && headerPx < maxPx) {
                    val newValue = (headerPx + delta).coerceAtMost(maxPx)
                    val used = newValue - headerPx
                    headerPx = newValue
                    return Offset(0f, used)
                }
                return Offset.Zero
            }
        }
    }

    Column(Modifier.fillMaxSize().pageBackground().nestedScroll(connection)) {
        HeroHeader(
            "سالن‌های ورزشی فوتسال استان اصفهان",
            height = with(density) { currentPx.toDp() },
            progress = progress,
        )
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            placeholder = { Text("جستجوی سالن ...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = BlueMain) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "پاک کردن")
                    }
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White,
                focusedBorderColor = BlueMain,
                unfocusedBorderColor = Color.Transparent,
            ),
        )
        if (results.isEmpty()) {
            Text(
                "موردی پیدا نشد",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                textAlign = TextAlign.Center,
                color = Color.White,
            )
        } else {
            GymList(results, onOpen, Modifier.fillMaxSize())
        }
    }
}

@Composable
fun FavoritesTab(favorites: FavoritesStore, onOpen: (Gym) -> Unit) {
    val items = gyms.filter { it.id in favorites.ids }
    Column(Modifier.fillMaxSize().pageBackground()) {
        HeroHeader("علاقه‌مندی‌ها", compact = true)
        if (items.isEmpty()) {
            Text(
                "هنوز سالنی را به علاقه‌مندی‌ها اضافه نکرده‌اید.\nدر صفحه‌ی هر سالن روی قلب بزنید.",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                textAlign = TextAlign.Center,
                color = Color.White,
                lineHeight = 26.sp,
            )
        } else {
            GymList(items, onOpen, Modifier.fillMaxSize())
        }
    }
}

@Composable
private fun InfoCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            content = content,
        )
    }
}

private fun sendEmail(context: Context) {
    try {
        context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$CONTACT_EMAIL")))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "برنامه‌ی ایمیل پیدا نشد: $CONTACT_EMAIL", Toast.LENGTH_LONG).show()
    }
}

@Composable
fun AboutTab() {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().pageBackground()) {
        HeroHeader("درباره ما", compact = true)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            AppLogo(size = 110)
            Text(
                "آدرس سالن‌های ورزشی فوتسال استان اصفهان",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = Color.White,
                textAlign = TextAlign.Center,
            )
            InfoCard {
                Text(
                    "این برنامه آدرس و موقعیت سالن‌های ورزشی فوتسال استان اصفهان را روی نقشه‌های گوگل‌مپ و بلد نمایش می‌دهد.",
                    textAlign = TextAlign.Center,
                    color = Color(0xFF2A3560),
                    lineHeight = 26.sp,
                )
            }
            InfoCard {
                Text(
                    "ناشر: روح‌الله صفدری",
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold,
                    color = Navy,
                    fontSize = 16.sp,
                )
                Text(
                    "© ۱۴۰۵ روح‌الله صفدری. تمامی حقوق محفوظ است.",
                    textAlign = TextAlign.Center,
                    color = Color(0xFF5A6690),
                    fontSize = 13.sp,
                )
            }
            InfoCard {
                Text(
                    "تماس با ما",
                    fontWeight = FontWeight.Bold,
                    color = Navy,
                    fontSize = 16.sp,
                )
                Row(
                    modifier = Modifier.clickable { sendEmail(context) },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        Icons.Default.Email,
                        contentDescription = null,
                        tint = BlueMain,
                        modifier = Modifier.size(20.dp),
                    )
                    Text(
                        "  $CONTACT_EMAIL",
                        color = BlueMain,
                        fontSize = 15.sp,
                        textDecoration = TextDecoration.Underline,
                    )
                }
            }
        }
    }
}

@Composable
fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Navy) {
        val colors = NavigationBarItemDefaults.colors(
            selectedIconColor = Color.White,
            selectedTextColor = Gold,
            unselectedIconColor = Color(0xFF9FB0E8),
            unselectedTextColor = Color(0xFF9FB0E8),
            indicatorColor = BlueMain,
        )
        NavigationBarItem(
            selected = selected == 0,
            onClick = { onSelect(0) },
            icon = { Icon(Icons.Default.Home, contentDescription = null) },
            label = { Text("خانه") },
            colors = colors,
        )
        NavigationBarItem(
            selected = selected == 1,
            onClick = { onSelect(1) },
            icon = { Icon(Icons.Default.Star, contentDescription = null) },
            label = { Text("علاقه‌مندی‌ها") },
            colors = colors,
        )
        NavigationBarItem(
            selected = selected == 2,
            onClick = { onSelect(2) },
            icon = { Icon(Icons.Default.Info, contentDescription = null) },
            label = { Text("درباره ما") },
            colors = colors,
        )
    }
}
