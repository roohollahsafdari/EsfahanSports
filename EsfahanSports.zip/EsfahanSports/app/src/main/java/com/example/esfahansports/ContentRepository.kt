package com.example.esfahansports

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * دریافت اطلاعات آنلاین از سایت.
 * هر خطایی (نبود اینترنت، خرابی سایت، فایل ناقص) بی‌صدا نادیده گرفته می‌شود و
 * اپ با آخرین اطلاعات ذخیره‌شده یا اطلاعات داخلی ادامه می‌دهد.
 */
class ContentRepository(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("online_content", Context.MODE_PRIVATE)

    /** آخرین اطلاعات معتبر ذخیره‌شده؛ در صورت نبود یا خرابی null */
    fun loadCached(): AppContent? {
        val raw = prefs.getString(KEY_DATA, null) ?: return null
        return try {
            parse(raw)
        } catch (e: Exception) {
            null
        }
    }

    /** اگر نسخه‌ی جدیدتری روی سایت باشد دریافت و ذخیره می‌کند؛ در غیر این صورت یا هنگام خطا null */
    suspend fun refresh(): AppContent? = withContext(Dispatchers.IO) {
        try {
            val remoteVersion = JSONObject(download("version.json")).getInt("version")
            val cachedVersion = if (prefs.contains(KEY_DATA)) prefs.getInt(KEY_VERSION, 0) else 0
            if (remoteVersion <= cachedVersion) return@withContext null
            val raw = download("data.json")
            val content = parse(raw)
            prefs.edit().putString(KEY_DATA, raw).putInt(KEY_VERSION, content.version).apply()
            content
        } catch (e: Exception) {
            null
        }
    }

    private fun download(file: String): String {
        val conn = URL(BASE_URL + file).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 6000
            conn.readTimeout = 8000
            conn.useCaches = false
            conn.setRequestProperty("Cache-Control", "no-cache")
            if (conn.responseCode != 200) throw IllegalStateException("HTTP ${conn.responseCode}")
            val bytes = conn.inputStream.use { it.readNBytesLimited(MAX_BYTES) }
            return String(bytes, Charsets.UTF_8)
        } finally {
            conn.disconnect()
        }
    }

    private fun java.io.InputStream.readNBytesLimited(limit: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (true) {
            val n = read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            if (out.size() > limit) throw IllegalStateException("too large")
        }
        return out.toByteArray()
    }

    companion object {
        const val BASE_URL = "https://saigroup.ir/futsal/"
        private const val KEY_DATA = "data"
        private const val KEY_VERSION = "version"
        private const val MAX_BYTES = 2 * 1024 * 1024
        private val COORDS = Regex("latitude=(-?[0-9.]+)&longitude=(-?[0-9.]+)")

        private fun JSONObject.str(key: String, fallback: String): String {
            val v = optString(key, "").trim()
            return if (v.isEmpty()) fallback else v
        }

        private fun String.httpOrEmpty(): String =
            if (startsWith("https://") || startsWith("http://")) this else ""

        /** فایل data.json را به اطلاعات اپ تبدیل می‌کند؛ اگر معتبر نباشد استثنا می‌دهد. */
        fun parse(raw: String): AppContent {
            val root = JSONObject(raw)
            val b = BuiltInContent
            val home = root.optJSONObject("home") ?: JSONObject()
            val det = root.optJSONObject("details") ?: JSONObject()
            val about = root.optJSONObject("about") ?: JSONObject()

            val list = ArrayList<Gym>()
            val used = HashSet<Int>()
            val arr = root.getJSONArray("gyms")
            for (i in 0 until arr.length()) {
                val g = arr.optJSONObject(i) ?: continue
                if (!g.optBoolean("active", true)) continue
                val id = g.optInt("id", 0)
                val name = g.optString("name", "").trim()
                if (id < 1 || name.isEmpty() || !used.add(id)) continue
                val balad = g.optString("balad", "").trim().httpOrEmpty()
                val google = g.optString("google", "").trim().httpOrEmpty()
                val m = COORDS.find(balad)
                list.add(
                    Gym(
                        id = id,
                        name = name,
                        city = g.optString("city", "").trim(),
                        address = g.optString("address", "").trim(),
                        baladUrl = balad,
                        googleUrl = google,
                        latitude = m?.groupValues?.get(1)?.toDoubleOrNull(),
                        longitude = m?.groupValues?.get(2)?.toDoubleOrNull(),
                        hasMatches = false,
                        imageUrl = g.optString("image", "").trim().httpOrEmpty().ifEmpty { null },
                    )
                )
            }
            if (list.isEmpty()) throw IllegalStateException("no gyms")

            return AppContent(
                version = root.optInt("version", 0),
                home = HomeContent(
                    title = home.str("title", b.home.title),
                    subtitle = home.optString("subtitle", "").trim(),
                    topImage = home.optString("top_image", "").trim().httpOrEmpty(),
                    logo = home.optString("logo", "").trim().httpOrEmpty(),
                    searchHint = home.str("search_hint", b.home.searchHint),
                ),
                details = DetailsContent(
                    addressLabel = det.str("address_label", b.details.addressLabel),
                    googleButton = det.str("google_button", b.details.googleButton),
                    baladButton = det.str("balad_button", b.details.baladButton),
                    locationButton = det.str("location_label", b.details.locationButton),
                ),
                about = AboutContent(
                    title = about.str("title", b.about.title),
                    text = about.str("text", b.about.text),
                    sources = about.str("sources", b.about.sources),
                    publisher = about.str("publisher", b.about.publisher),
                    copyright = about.str("copyright", b.about.copyright),
                    contactTitle = about.str("contact_title", b.about.contactTitle),
                    email = about.str("email", b.about.email),
                ),
                gyms = list,
            )
        }
    }
}
