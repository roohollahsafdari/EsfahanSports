package com.example.esfahansports

data class Gym(
    val id: Int,
    val name: String,
    val city: String,
    val type: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
)
