package com.example.esfahansports

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    GymApp()
                }
            }
        }
    }
}

/** یکسان‌سازی حروف عربی/فارسی و حذف نیم‌فاصله برای جستجوی دقیق‌تر */
private fun normalize(s: String): String = s
    .replace('ي', 'ی')
    .replace('ك', 'ک')
    .replace("‌", "")
    .replace(" ", "")
    .lowercase()

private fun openInMaps(context: Context, gym: Gym) {
    val geo = Uri.parse(
        "geo:${gym.latitude},${gym.longitude}?q=${gym.latitude},${gym.longitude}(${Uri.encode(gym.name)})"
    )
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, geo))
    } catch (e: ActivityNotFoundException) {
        val web = Uri.parse("https://www.google.com/maps/search/?api=1&query=${gym.latitude},${gym.longitude}")
        context.startActivity(Intent(Intent.ACTION_VIEW, web))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GymApp() {
    var query by remember { mutableStateOf("") }
    val results = remember(query) {
        val q = normalize(query)
        if (q.isEmpty()) sampleGyms
        else sampleGyms.filter {
            normalize(it.name).contains(q) ||
                normalize(it.address).contains(q) ||
                normalize(it.city).contains(q) ||
                normalize(it.type).contains(q)
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("سالن‌های ورزشی استان اصفهان") }) }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(horizontal = 16.dp)
                .fillMaxSize()
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                singleLine = true,
                placeholder = { Text("جستجوی نام، شهر یا نوع سالن") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "پاک کردن")
                        }
                    }
                },
            )

            if (results.isEmpty()) {
                Text(
                    "موردی پیدا نشد",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyLarge,
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(results, key = { it.id }) { gym -> GymCard(gym) }
                }
            }
        }
    }
}

@Composable
fun GymCard(gym: Gym) {
    val context = LocalContext.current
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(gym.name, style = MaterialTheme.typography.titleMedium)
            Text("${gym.city} • ${gym.type}", style = MaterialTheme.typography.bodyMedium)
            Text(gym.address, style = MaterialTheme.typography.bodyMedium)
            Row(Modifier.padding(top = 8.dp)) {
                Button(onClick = { openInMaps(context, gym) }) {
                    Icon(Icons.Default.Place, contentDescription = null)
                    Text("  نمایش روی نقشه")
                }
            }
        }
    }
}
