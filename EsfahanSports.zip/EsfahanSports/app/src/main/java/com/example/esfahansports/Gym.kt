package com.example.esfahansports

data class Gym(
    val id: Int,
    val name: String,
    val city: String,
    val address: String,
    val baladUrl: String,
    val googleUrl: String,
    val latitude: Double?,
    val longitude: Double?,
    val hasMatches: Boolean,
    val aliases: List<String> = emptyList(),
)
