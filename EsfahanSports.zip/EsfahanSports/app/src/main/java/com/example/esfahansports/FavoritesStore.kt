package com.example.esfahansports

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class FavoritesStore(context: Context) {
    private val prefs = context.getSharedPreferences("favorites", Context.MODE_PRIVATE)

    var ids: Set<Int> by mutableStateOf(
        (prefs.getStringSet("ids", emptySet()) ?: emptySet())
            .mapNotNull { it.toIntOrNull() }
            .toSet()
    )
        private set

    fun toggle(id: Int) {
        ids = if (id in ids) ids - id else ids + id
        prefs.edit().putStringSet("ids", ids.map { it.toString() }.toSet()).apply()
    }
}
