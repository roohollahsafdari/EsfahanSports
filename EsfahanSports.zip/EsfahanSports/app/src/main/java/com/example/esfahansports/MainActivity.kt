package com.example.esfahansports

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(primary = BlueMain, secondary = Gold),
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AppRoot()
                }
            }
        }
    }
}

@Composable
fun AppRoot() {
    val context = LocalContext.current
    val favorites = remember { FavoritesStore(context) }

    var showSplash by rememberSaveable { mutableStateOf(true) }
    var tab by rememberSaveable { mutableStateOf(0) }
    var openedGymId by rememberSaveable { mutableStateOf(-1) }

    LaunchedEffect(Unit) {
        if (showSplash) {
            delay(2000)
            showSplash = false
        }
    }

    if (showSplash) {
        SplashScreen()
        return
    }

    val openedGym = gyms.firstOrNull { it.id == openedGymId }

    BackHandler(enabled = openedGym != null) { openedGymId = -1 }

    if (openedGym != null) {
        DetailScreen(gym = openedGym, favorites = favorites, onBack = { openedGymId = -1 })
        return
    }

    Scaffold(
        bottomBar = { BottomBar(selected = tab, onSelect = { tab = it }) },
    ) { padding ->
        androidx.compose.foundation.layout.Box(Modifier.padding(padding)) {
            when (tab) {
                0 -> HomeTab(onOpen = { openedGymId = it.id })
                1 -> FavoritesTab(favorites, onOpen = { openedGymId = it.id })
                else -> AboutTab()
            }
        }
    }
}
